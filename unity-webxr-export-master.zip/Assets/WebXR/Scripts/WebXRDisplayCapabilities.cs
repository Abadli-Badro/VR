﻿[System.Serializable]
public class WebXRDisplayCapabilities
{
	public bool supportsInline;
	public bool supportsImmersiveVR;
	public bool supportsImmersiveAR;
	public bool isSecureContext;
}
